import requests
from bs4 import BeautifulSoup
from fpdf import FPDF
from PIL import Image
import io
import re

"""
Function to scrape general information:
        try: Sending HTTP GET requests,BeautfulSoupsoup.soup 
             (Parametar URL)
             Parse the HTML content and get infromation from first paragraph tag
        output:
              General Infromation about Karate
"""
def scrape_general_info(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    content = soup.find('div', {'class': 'mw-parser-output'})
    paragraphs = content.find_all('p', recursive=False)
    introduction = "\n\n".join([para.get_text().strip() for para in paragraphs[:2] if para.get_text().strip()])
    return introduction, content

"""
 Function to scrape equipment information:
        try: HTML Content, Find out the practise as header collecting the list items 
            (Parameter Url)
             regex for index ajustment and avoid the digit 
        output:
            a list  Equipment Of Karate 
"""
def equipmnet_fatching(url):
    response = requests.get(url)
    content = BeautifulSoup(response.content, 'html.parser')
    container_divs = content.find_all('div', class_='elementor-widget-container')
    
    equipment_info = []
    custom_number = 1 
    for container_div in container_divs:
        h3_tags = container_div.find_all('h3')
        for index, tag in enumerate(h3_tags):
            if index == 0: 
                continue
            tag_text = tag.get_text().strip()
            if re.match(r'^[2-9]', tag_text):  # i avoid custom index and i need only index 2-9 
                cleaned_text = re.sub(r'^[2-9]\s*', '', tag_text) # need the text only 
                equipment_info.append(f"{custom_number} {cleaned_text}") #than i add my own index 
                custom_number += 1 
    return "\n".join(equipment_info)



"""
Function to download image:
       try: Location for image url within infobox-image sections of the wikipedia 
           and download the image
           (Parameter CONTENT)
    output:
           Downloading Image of Related to Karate
"""
def download_image(content):
    infobox_image_tag = content.find('td', {'class': 'infobox-image'})
    image_url = "https:" + infobox_image_tag.find('img')['src']
    image_response = requests.get(image_url)
    if image_response.status_code == 200:
        try:
            image = Image.open(io.BytesIO(image_response.content))
            image_filename = "karate_image.jpg"
            image.save(image_filename)
            print("Image downloaded and saved successfully.")
            return image_filename
        except Exception as e:
            print(f"Error processing image: {e}")
    else:
        print(f"Failed to download image, status code: {image_response.status_code}")
        print(image_response.text)  
    return None

"""
Function to create PDF:
      try: all of the things General Information, 
           Image, Equipment Will print in a pdf. Use FPDF Library  
           (Parameter IMAGE_FILENAME, introduction, equipment)
     output:
          a pdf will for storing the above all infromation
"""
def create_pdf(image_filename, introduction, equipment):
    class PDF(FPDF):
        def header(self):
            self.set_font('Arial', 'B', 12)
            self.cell(0, 10, 'Karate General ', 0, 1, 'C')

        def footer(self):
            self.set_y(-15)
            self.set_font('Arial', 'I', 8)
            self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')

        def chapter_title(self, title):
            self.set_font('Arial', 'B', 12)
            self.cell(0, 10, title.encode('latin1', 'replace').decode('latin1'), 0, 1, 'L')
            self.ln(10)

        def chapter_body(self, body):
            self.set_font('Arial', '', 12)
            self.multi_cell(0, 10, body.encode('latin1', 'replace').decode('latin1'))
            self.ln()

        def add_image_with_text(self, image_path, text, equipment):
            self.image(image_path, x=10, y=50, w=50)
            self.set_xy(70, 50)
            self.multi_cell(0, 10, text.encode('latin1', 'replace').decode('latin1'))
            self.set_xy(10, 150)
            self.set_font('Arial', 'B', 12)
            self.cell(0, 10, 'Equipment:', 0, 1, 'L')
            self.set_font('Arial', '', 12)
            self.multi_cell(0, 10, equipment.encode('latin1', 'replace').decode('latin1'))

    """
    1.Create instance of FPDF class
    2.Add a page
    3.Add title and introduction text with image
    4.Save the PDF
    """
    pdf = PDF()
    pdf.add_page()
    pdf.chapter_title('Introduction')
    pdf.add_image_with_text(image_filename, introduction, equipment)
    pdf.output("General.pdf")
    print("PDF has been created successfully.")

"""
Main function the task of all management 

"""
def main():
    url = "https://en.wikipedia.org/wiki/Karate" 
    url2= "https://mmafactory.com.au/blog/karate-training-equipment-guide"  # for equipment scraping 
    introduction, content = scrape_general_info(url)
    equipment_info = equipmnet_fatching(url2)
    image_filename = download_image(content)
    if image_filename:
        create_pdf(image_filename, introduction,  equipment_info)

if __name__ == "__main__":
    main()