import pandas as pd
from fpdf import FPDF
import requests
from bs4 import BeautifulSoup
import os
import urllib.parse

"""
  Try: 1. define my data Frame (from csv file)
       2. from df find  name convert it as lower string
       3. that are is eual to athlete name as lower string
    
"""


def read_csv(file_path, athlete_name):
    df = pd.read_csv(file_path)
    df['Name'] = df['Name'].str.strip().str.lower()
    filtered_df = df[df['Name'].str.lower() == athlete_name.lower()]
    return filtered_df

""" 
   try : 1. Organized the name as index parts based. 
               
"""

def reformat_name(athlete_name):
    parts = athlete_name.split()
    if len(parts) == 4:
        return f"{parts[3].capitalize()} {parts[0].capitalize()}"
    elif len(parts) == 3:
        return f"{parts[2].capitalize()} {parts[0].capitalize()}"
    elif len(parts) == 2:
        return f"{parts[1].capitalize()} {parts[0].capitalize()}"
    else:
        return athlete_name.capitalize()
"""
  try :1. scraping name and image of any athlete (karate)
       2. find all p tag scrap the paragraph than break
       3. find td tag than class infobox-image for scraping image of that player
  output: general info of player and picture url 
"""

def get_athlete_info(athlete_name):
    formatted_name = reformat_name(athlete_name)
    wiki_url = f"https://en.wikipedia.org/wiki/{urllib.parse.quote(formatted_name.replace(' ', '_'))}"
    response = requests.get(wiki_url)
    if response.status_code != 200:
        print(f"Failed to fetch Wikipedia page, status code: {response.status_code}")  
        return None, None, None

    soup = BeautifulSoup(response.content, 'html.parser')
    summary = ''
    for paragraph in soup.find_all('p'):
        if paragraph.text.strip():
            summary = paragraph.text.strip()
            break

    infobox_image = soup.find('td', {'class': 'infobox-image'})
    if infobox_image and infobox_image.find('img'):
        image_url = 'https:' + infobox_image.find('img')['src']
    else:
        image_url = None

    return summary, wiki_url, image_url


"""
    try:1. use user agent .. 
        downloading picture .. 
        2.defined image downloaded path 
    output:
        image downloaded for that athlete
"""

def download_image(image_url, athlete_name):
    if not image_url:
        return None

    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
    try:
        response = requests.get(image_url, headers=headers, stream=True)
        if response.status_code == 200 and 'image' in response.headers['Content-Type']:
            image_path = f"{athlete_name.replace(' ', '_')}.jpg"
            with open(image_path, 'wb') as f:
                for chunk in response.iter_content(1024):
                    f.write(chunk)
            return image_path
        else:
            print(f"Failed to download image, status code: {response.status_code}") 
    except Exception as e:
        print(f"Error occurred while downloading the image: {e}") 
    return None

"""
    try: creating pdf ,styling,heading, 
    output: A nice pdf 
"""

def create_pdf(athlete_name, athlete_info, image_path, events):
    class PDF(FPDF):
        def header(self):
            self.set_font('Arial', 'B', 16)
            self.cell(0, 10, athlete_name.encode('latin1', 'replace').decode('latin1'), 0, 1, 'C')
            self.ln(10)

        def footer(self):
            self.set_y(-15)
            self.set_font('Arial', 'I', 8)
            self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')

    pdf = PDF()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)

    pdf.set_font('Arial', 'B', 16)
    pdf.ln(4)

    image_height = 50  
    if image_path and os.path.exists(image_path):
        pdf.image(image_path, x=10, y=pdf.get_y(), w=50, h=image_height)
        pdf.set_xy(65, pdf.get_y()) 
    else:
        print("Image not found in the specified path.") 

    pdf.set_font('Arial', '', 12)
    pdf.multi_cell(0, 10, athlete_info.encode('latin1', 'replace').decode('latin1'), border=0)

    pdf.ln(10)
    pdf.set_font('Arial', 'B', 14)
    pdf.cell(0, 10, 'Medals:', 0, 1, 'L')

    pdf.set_font('Arial', '', 12)
    for _, row in events.iterrows():
        medal_info = f"{row['Year']} - {row['Event']} - {row['Medal'].capitalize()}"
        pdf.cell(0, 10, medal_info.encode('latin1', 'replace').decode('latin1'), 0, 1)

    output_path = f"{athlete_name.replace(' ', '_')}_info.pdf"
    pdf.output(output_path)
    print(f"PDF has been created successfully.")

"""
   try: calling all function in that function
   output : All of those above information are in one pdf 
"""

def main():
    csv_file_path = 'Year Winners.csv'
    athlete_name = input("Enter the athlete's name: ").strip()
    events = read_csv(csv_file_path, athlete_name)

    if events.empty:
        print("No data found for the athlete.")
        return
    athlete_info, wiki_url, image_url = get_athlete_info(athlete_name)
    if not athlete_info:
        print("No Wikipedia page found for the athlete.")
        return
    image_path = download_image(image_url, athlete_name)
    if not image_path:
        print("No image found for the athlete.")
        return
    create_pdf(athlete_name, athlete_info, image_path, events)

if __name__ == "__main__":
    main()

